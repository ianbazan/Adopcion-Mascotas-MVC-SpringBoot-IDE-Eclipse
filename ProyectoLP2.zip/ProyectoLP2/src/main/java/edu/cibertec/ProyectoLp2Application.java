package edu.cibertec;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoLp2Application {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoLp2Application.class, args);
	}

}
